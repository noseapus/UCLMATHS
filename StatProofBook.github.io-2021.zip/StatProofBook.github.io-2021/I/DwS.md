---
layout: page
title: "Definitions without Source"
---


- [Beta-distributed data](/D/beta-data)
- [Binomial observations](/D/bin-data)
- [Conditional differential entropy](/D/dent-cond)
- [Dirichlet-distributed data](/D/dir-data)
- [Estimation matrix](/D/emat)
- [Full probability model](/D/fpm)
- [Generative model](/D/gm)
- [Joint differential entropy](/D/dent-joint)
- [Joint likelihood](/D/jl)
- [Likelihood function](/D/lf)
- [Log-likelihood function](/D/llf)
- [Marginal likelihood](/D/ml)
- [Maximum likelihood estimation](/D/mle)
- [Maximum log-likelihood](/D/mll)
- [Multinomial observations](/D/mult-data)
- [Posterior distribution](/D/post)
- [Prior distribution](/D/prior)
- [Residual variance](/D/resvar)
- [Sample correlation matrix](/D/corrmat-samp)
